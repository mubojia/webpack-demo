import { bubbleSort } from '../../../../src/ts/index';
import { testSortAlgorithm } from './sort-algorithm-tests';

testSortAlgorithm(bubbleSort, 'Bubble Sort');

